﻿namespace Homies.Models;

using System.ComponentModel.DataAnnotations;

public class AllTypesViesModel
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;
}
